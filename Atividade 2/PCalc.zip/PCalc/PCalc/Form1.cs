﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class fundo : Form
    {

        double numero1, numero2, resultado; //variáveis globais

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtNum1, "");
                numero2 = Convert.ToDouble(txtNum2.Text); //converte o conteúdo do TextBox para Double
            }
            catch (Exception ex) //Exceção
            {
                errorProvider2.SetError(txtNum2, "Número 2 inválido");
                txtNum2.Focus(); 
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não divida por zero." + MessageBoxButtons.OK); // Verificar se num2 é zero, caso sim, imprime um erro
                txtNum2.Text = "";
                txtNum2.Focus();
               
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear(); //Limpa todas as TextBox
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
            {
                Close();
            }
        }

        public fundo()
        {
            InitializeComponent();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out numero1)) //condição de negação para Double.TryParse();
            {
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
                txtNum1.Focus();
            }
            else
            {
                errorProvider1.SetError(txtNum1, "");
            }
        }
    }
}
