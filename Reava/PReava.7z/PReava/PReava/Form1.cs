﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] MatrizA = new double[10] {4, 4, 4, 4, 4, 2, 2, 2, 2, 5};
            double[] MatrizB = new double[10] {5, 7, 7, 9, 9, 3, 3, 5, 9, 1};

            for (int cont = 0; cont <= 9; cont++)
            {
                if (MatrizA[cont] % 2 == 0)
                {
                    MatrizA[cont] *= 4;
                }
                else
                {
                    MatrizA[cont] += 4;
                }

                if (MatrizB[cont] % 2 == 0)
                {
                    MatrizB[cont] *= 4;
                }
                else
                {
                    MatrizB[cont] += 4;
                }
            }
                lstbxMatrizes.Items.Add("Posição: 0 Matriz A=" + MatrizA[0].ToString("f2") + " Matriz B=" + MatrizB[0].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 1 Matriz A=" + MatrizA[1].ToString("f2") + " Matriz B=" + MatrizB[1].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 2 Matriz A=" + MatrizA[2].ToString("f2") + " Matriz B=" + MatrizB[2].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 3 Matriz A=" + MatrizA[3].ToString("f2") + " Matriz B=" + MatrizB[3].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 4 Matriz A=" + MatrizA[4].ToString("f2") + " Matriz B=" + MatrizB[4].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 5 Matriz A=" + MatrizA[5].ToString("f2") + " Matriz B=" + MatrizB[5].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 6 Matriz A=" + MatrizA[6].ToString("f2") + " Matriz B=" + MatrizB[6].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 7 Matriz A=" + MatrizA[7].ToString("f2") + " Matriz B=" + MatrizB[7].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 8 Matriz A=" + MatrizA[8].ToString("f2") + " Matriz B=" + MatrizB[8].ToString("f2"));
                lstbxMatrizes.Items.Add("Posição: 9 Matriz A=" + MatrizA[9].ToString("f2") + " Matriz B=" + MatrizB[9].ToString("f2"));
            }
        }
    
}
