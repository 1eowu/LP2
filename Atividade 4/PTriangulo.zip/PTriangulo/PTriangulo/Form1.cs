﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtLadoA_TextChanged(object sender, EventArgs e)
        {
   
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Lado inválido.");
                txtLadoA.Focus();

            }
            else
            {
                if (ladoA <= 0)
                {
                    MessageBox.Show("Lado deve ser maior que zero.");
                    txtLadoA.Focus();
                }
            }

        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado inválido.");
                txtLadoB.Focus();

            }
            else
            {
                if (ladoB <= 0)
                {
                    MessageBox.Show("Lado deve ser maior que zero.");
                    txtLadoB.Focus();
                }
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado inválido.");
                txtLadoC.Focus();

            }
            else
            {
                if (ladoC <= 0)
                {
                    MessageBox.Show("Lado deve ser maior que zero.");
                    txtLadoC.Focus();
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((ladoA < ladoB + ladoC) && (ladoB < ladoA + ladoC) && (ladoC < ladoA + ladoB))
            {
                MessageBox.Show("É um triangulo");

                if ((ladoA == ladoB) && (ladoB == ladoC))
                {
                    MessageBox.Show("Equilátero");
                }
                else if ((ladoA == ladoB) || (ladoB == ladoC) || (ladoA == ladoC))
                {
                    MessageBox.Show("Isósceles");
                }
                else
                {
                    MessageBox.Show("Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
        
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
